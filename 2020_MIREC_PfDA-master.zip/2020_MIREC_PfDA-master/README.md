# 2020_MIREC_PfDA
 Python for data analysis (MIREC), Higher School of Economics, 2020, 4th module. 
